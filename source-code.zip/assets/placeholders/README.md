# Placeholder Asset Structure

This directory intentionally contains only lightweight placeholders and documentation.
Runtime assets are generated into `public/assets/` using:

```bash
python3 tools/generate_assets.py
```

Do not commit large binary files in this stage.
