Delete coin.png.
