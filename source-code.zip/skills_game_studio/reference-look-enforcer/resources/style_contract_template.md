# Style Contract Template

## Palette
- Named swatches:
- Terrain ramp:
- UI ramp:
- FX ramp:

## Outlines
- World outline px:
- UI outline px:
- Maximum outline px:

## HUD Layout
- Viewport:
- topText anchor/x/y/font:
- rightText anchor/x/y/font:
- portrait anchor/x/y/scale:

## Typography
- Style:
- Case:
- Letter spacing:
- Line height:

## Bloom / Glow
- enabled:
- threshold:
- strength:
- radius:
- downsample:
- tint:

## Do / Don't
- Do:
- Don't:
