Change HUD positions by 30px.
