We have gameplay, rendering, networking, tools, and UI modules.
Need clear boundaries and a script that catches forbidden imports.
