# Dialogue Scene Template

## Scene ID

## Narrative Goal

## Speakers
- Speaker:
- Intent:

## Beats
1. 
2. 
3. 

## Constraints
- Max line length:
- Placeholder tokens:
- Localization risks:
