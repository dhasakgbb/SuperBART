Need lore bible and voice guides for a fantasy city under siege.
Localization required for EN, ES, and JA.
