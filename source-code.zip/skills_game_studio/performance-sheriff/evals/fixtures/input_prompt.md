Target: 60fps on mid-tier hardware. Need combat and hub scene budgets, plus release gating checklist.
