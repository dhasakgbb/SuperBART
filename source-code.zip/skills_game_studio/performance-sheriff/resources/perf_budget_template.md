# Performance Budget Template

## Target Platforms
- 

## Frame Time Budgets
- Gameplay p50:
- Gameplay p95:
- Gameplay p99:

## Memory Budgets
- Runtime memory cap:
- Streaming cache cap:

## Load/Transition Budgets
- Boot time:
- Scene transition:

## Measurement Protocol
- Sample size:
- Capture method:
- Hardware profile:
