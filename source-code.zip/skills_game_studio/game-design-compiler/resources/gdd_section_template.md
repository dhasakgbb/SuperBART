# GDD Section Template

## Core Loop
- Player action:
- World response:
- Reward cadence:

## MVP Scope
- Must ship:
- Nice-to-have:
- Excluded from MVP:

## Systems Overview
- Progression:
- Combat/interaction:
- Economy:

## Content Plan
- Level count:
- Encounter pattern:
- Narrative delivery mode:

## Risks
- Technical:
- Design:
- Schedule:

## Validation Plan
- Prototype checks:
- Playtest checkpoints:
