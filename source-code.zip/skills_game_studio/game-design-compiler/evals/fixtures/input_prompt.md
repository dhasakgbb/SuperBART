Concept: Couch co-op action game where players defend a moving train from waves.
Constraints: 3-person team, 4-month MVP, PC only.
Need: A production-ready GDD and phase-0 backlog.
