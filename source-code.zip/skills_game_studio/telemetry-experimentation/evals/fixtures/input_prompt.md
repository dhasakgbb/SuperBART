Need telemetry schema for tutorial completion, mission completion, and store purchases with experiment support.
