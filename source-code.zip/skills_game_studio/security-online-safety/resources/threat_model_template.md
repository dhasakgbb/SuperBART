# Threat Model Template

## Scope

## Assets
- 

## Trust Boundaries
- 

## Attackers and Abuse Actors
- 

## Abuse Paths
1.
2.

## Mitigations
- Preventive:
- Detective:
- Response:

## Owners
- 
