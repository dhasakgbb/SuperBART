Need threat model + baseline controls for online co-op with friend invites and text chat.
