# Encounter Pacing Template

## Level / Segment

## Target Duration

## Beat Timeline
| Time Window | Encounter Type | Intensity (1-5) | Goal |
| --- | --- | --- | --- |
| 00:00-02:00 | Tutorial skirmish | 2 | Teach movement |

## Downtime Windows
- 

## Failure/Recovery Design
- 

## Difficulty Tuning Notes
- 
