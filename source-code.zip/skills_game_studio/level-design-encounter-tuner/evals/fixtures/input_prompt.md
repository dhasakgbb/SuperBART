Create level spec and pacing plan for a 15-minute infiltration mission with stealth opener and boss finish.
