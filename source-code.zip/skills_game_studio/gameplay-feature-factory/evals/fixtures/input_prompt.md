Implement ticket: tickets/wall_jump.md
Acceptance criteria: jump allowed for 200ms after wall contact; cooldown 500ms; covered by tests.
