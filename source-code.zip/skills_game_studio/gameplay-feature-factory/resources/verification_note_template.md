# Feature Verification: <feature_id>

## Ticket
- Path: `tickets/<feature_id>.md`

## Acceptance Criteria Mapping
1. Criterion:
   - Implementation evidence:
   - Test evidence:

## Risks
- 

## Follow-ups
- 
