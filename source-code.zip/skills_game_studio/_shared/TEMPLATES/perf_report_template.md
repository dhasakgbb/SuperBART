# Performance Report: <feature or scene>

## Test Configuration
- Build:
- Platform:
- Scene:
- Capture tool:

## Budgets
- Frame time budget:
- Memory budget:
- Load-time budget:

## Measurements
- p50:
- p95:
- p99:

## Regressions

## Actions
1.
2.
