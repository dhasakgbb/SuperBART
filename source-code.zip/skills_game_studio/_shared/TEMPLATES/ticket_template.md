# Ticket: <title>

## Context
- Problem:
- Why now:

## Scope
- In scope:
- Out of scope:

## Acceptance Criteria
1. 
2. 
3. 

## Validation
- Tests:
- Manual checks:

## Delivery
- Owner:
- Estimate:
- Dependencies:
