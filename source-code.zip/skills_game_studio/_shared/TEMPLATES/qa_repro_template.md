# QA Repro Case: <title>

## Build + Environment
- Build:
- Platform:
- Input device:

## Reproduction Steps
1.
2.
3.

## Expected Result

## Actual Result

## Attachments
- Screenshot/video:
- Logs:

## Notes
