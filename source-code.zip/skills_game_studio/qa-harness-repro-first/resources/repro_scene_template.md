# Repro Scene: <scene_id>

## Intent

## Setup
- Build:
- Platform:
- Save state / seed:

## Steps
1.
2.
3.

## Deterministic Expected Result

## Failure Signature

## Notes
