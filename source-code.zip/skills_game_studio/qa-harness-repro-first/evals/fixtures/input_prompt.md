Need reproducible QA harness for collision tunneling bug reported intermittently at high player speed.
