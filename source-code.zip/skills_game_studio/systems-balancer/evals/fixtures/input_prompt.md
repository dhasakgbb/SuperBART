Balance target: campaign should feel challenging but fair from level 1 to 10.
Need equations for HP, DPS, and currency pacing with sanity tests.
