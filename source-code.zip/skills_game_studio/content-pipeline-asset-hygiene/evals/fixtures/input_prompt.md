Need asset hygiene for textures/audio with strict naming rules and a validation script.
No engine-specific pipeline assumptions.
