Set up release automation for weekly builds using SemVer and CI checks.
Need reproducible metadata generation and rollback notes.
