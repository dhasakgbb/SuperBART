# FPS Capture Helper

1. Open browser devtools performance panel.
2. Start recording before level movement begins.
3. Play for 60 seconds including enemy interaction and goal reach.
4. Stop recording and inspect frame-time distribution.
5. Record p50/p95/p99 into `docs/perf_budget.md` report section.
