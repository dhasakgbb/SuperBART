# Repro Scenes

This folder contains deterministic repro scenarios for critical gameplay behaviors.

## Scene List
- `repro_enemy_side_hit.md`
- `repro_goal_completion.md`

Use `docs/qa_repro_playbook.md` for execution protocol.
